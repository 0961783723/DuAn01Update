package com.demoNhom11.DuAn01.ModelTam;

public class modelHoaDonChiTietTam {
    public String maSach;
    public int soLuong;
    public double giaBia;
    public double thanhTien;

    public modelHoaDonChiTietTam(String maSach, int soLuong, double giaBia, double thanhTien) {
        this.maSach = maSach;
        this.soLuong = soLuong;
        this.giaBia = giaBia;
        this.thanhTien = thanhTien;
    }
}
