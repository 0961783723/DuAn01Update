package com.demoNhom11.DuAn01.ModelTam;

public class model2 {
    public String loaiSach;
    public int tongTien;

    public model2(String loaiSach, int tongTien) {
        this.loaiSach = loaiSach;
        this.tongTien = tongTien;
    }
}
