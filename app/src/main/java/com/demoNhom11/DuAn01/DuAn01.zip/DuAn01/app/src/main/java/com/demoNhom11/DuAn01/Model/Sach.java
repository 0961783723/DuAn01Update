package com.demoNhom11.DuAn01.Model;

public class Sach {
    public String maSach;
    public String maTheLoai;
    public String tenSach;
    public String tacGia;
    public String NXB;
    public double giaBia;
    public int soLuong;

    public Sach(String maSach, String maTheLoai, String tenSach, String tacGia, String NXB, double giaBia, int soLuong) {
        this.maSach = maSach;
        this.maTheLoai = maTheLoai;
        this.tenSach = tenSach;
        this.tacGia = tacGia;
        this.NXB = NXB;
        this.giaBia = giaBia;
        this.soLuong = soLuong;
    }
}
