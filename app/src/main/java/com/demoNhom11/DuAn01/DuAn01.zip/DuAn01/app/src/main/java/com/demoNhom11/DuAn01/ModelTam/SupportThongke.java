package com.demoNhom11.DuAn01.ModelTam;

public class SupportThongke {
    public String date;
    public String month;
    public String year;
    public String maHoaDon;


    public SupportThongke(String date, String month, String year, String maHoaDon) {
        this.date = date;
        this.month = month;
        this.year = year;
        this.maHoaDon = maHoaDon;
    }
}
