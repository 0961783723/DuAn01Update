package com.demoNhom11.DuAn01.ModelTam;

public class model {
    public String sach;
    public int tongTien;

    public model(String sach, int tongTien) {
        this.sach = sach;
        this.tongTien = tongTien;
    }
}
