package com.demoNhom11.DuAn01.ModelTam;

public class modeTop10 {
    public String maSach;
    public int TongTien;

    public modeTop10(String maSach, int tongTien) {
        this.maSach = maSach;
        TongTien = tongTien;
    }
}
