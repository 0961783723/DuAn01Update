package com.demoNhom11.DuAn01.Model;

public class TheLoai {
    public String maTheLoai;
    public String tenTheLoai;
    public String moTa;
    public int viTri;

    public TheLoai(String maTheLoai, String tenTheLoai, String moTa, int viTri) {
        this.maTheLoai = maTheLoai;
        this.tenTheLoai = tenTheLoai;
        this.moTa = moTa;
        this.viTri = viTri;
    }
}
