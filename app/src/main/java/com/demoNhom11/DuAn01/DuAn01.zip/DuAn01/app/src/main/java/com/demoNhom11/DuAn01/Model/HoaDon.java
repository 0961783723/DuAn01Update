package com.demoNhom11.DuAn01.Model;

public class HoaDon {
    public String maHoadon;
    public String ngayMua;

    public HoaDon(String maHoadon, String ngayMua) {
        this.maHoadon = maHoadon;
        this.ngayMua = ngayMua;
    }
}
